#!/bin/sh

./halite -d "240 160" "python3 MyBot.py" "python3 MyBot.py"